package com.example.storyspan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookViewHolder> {

    Context context;
    List<Book> bookList;

    public BookAdapter(Context context, List<Book> bookList) {
        this.context = context;
        this.bookList = bookList;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new BookViewHolder(LayoutInflater.from(context).inflate(R.layout.book_card, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        holder.bookCover.setImageResource(bookList.get(position).getCoverImage());
        holder.bookName.setText(bookList.get(position).getBookName());
        holder.bookAuthor.setText(bookList.get(position).getAuthorName());

        double rating = bookList.get(position).getRating();
        int[] ratings = {R.drawable.rating0, R.drawable.rating1, R.drawable.rating2, R.drawable.rating3, R.drawable.rating4, R.drawable.rating5, R.drawable.rating6, R.drawable.rating7, R.drawable.rating8, R.drawable.rating9, R.drawable.rating10};

        int index = (int)rating * 2;
        if(rating % 1 > 0.25 && rating % 1 <= 0.75) index += 1;
        else if(rating % 1 > 0.75) index += 2;

        holder.bookRating.setImageResource(ratings[index]);
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }
}
