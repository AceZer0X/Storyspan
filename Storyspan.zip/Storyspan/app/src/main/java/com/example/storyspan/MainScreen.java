package com.example.storyspan;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;


public class MainScreen extends Fragment {
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.main_screen, container, false);

        // Логика заполнения чартов
        List<Book> bookList = new ArrayList<>();
        bookList.add(new Book("Процесс", "Франц Кафка", R.drawable.c, 4.58));
        bookList.add(new Book("Процесс", "Франц Кафка", R.drawable.c, 3.18));
        bookList.add(new Book("Процесс", "Франц Кафка", R.drawable.c, 4.58));
        bookList.add(new Book("Процесс", "Франц Кафка", R.drawable.c, 4.58));

        List<Collection> collectionList = new ArrayList<>();
        collectionList.add(new Collection("Favourites", R.drawable.a, bookList));
        collectionList.add(new Collection("Read", R.drawable.b, bookList));
        collectionList.add(new Collection("Favourites", R.drawable.a, bookList));
        collectionList.add(new Collection("Read", R.drawable.b, bookList));

        RecyclerView collections = view.findViewById(R.id.main_screen1_collections);
        collections.setLayoutManager(new LinearLayoutManager(getActivity()));
        collections.setAdapter(new CollectionAdapter(getContext(), collectionList));

        // Обработка событий
        BottomNavigationView bottomNavigationView = view.findViewById(R.id.main_screen1_menu);
        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch(item.getItemId()) {
                case R.id.home:
                    return true;
                case R.id.profile:
                    FragmentManager fragmentManager1 = getParentFragmentManager();
                    FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
                    fragmentTransaction1.replace(R.id.frame, new ProfileScreen());
                    fragmentTransaction1.commit();
                    break;
                case R.id.map:
                    FragmentManager fragmentManager2 = getParentFragmentManager();
                    FragmentTransaction fragmentTransaction2 = fragmentManager2.beginTransaction();
                    fragmentTransaction2.replace(R.id.frame, new MapScreen());
                    fragmentTransaction2.commit();
                    break;
            }
            return false;
        });

        return view;
    }
}