package com.example.storyspan;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class ProfileScreen extends Fragment {
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.profile_screen, container, false);

        // Логика заполнения чартов


        // Обработка событий
        BottomNavigationView bottomNavigationView = view.findViewById(R.id.profile_screen_menu);
        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch(item.getItemId()) {
                case R.id.home:
                    FragmentManager fragmentManager1 = getParentFragmentManager();
                    FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
                    fragmentTransaction1.replace(R.id.frame, new MainScreen());
                    fragmentTransaction1.commit();
                    break;
                case R.id.profile:
                    return true;
                case R.id.map:
                    FragmentManager fragmentManager2 = getParentFragmentManager();
                    FragmentTransaction fragmentTransaction2 = fragmentManager2.beginTransaction();
                    fragmentTransaction2.replace(R.id.frame, new MapScreen());
                    fragmentTransaction2.commit();
                    break;
            }
            return false;
        });

        return view;
    }
}
