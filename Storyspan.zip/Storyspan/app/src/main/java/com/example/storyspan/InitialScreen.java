package com.example.storyspan;

import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class InitialScreen extends Fragment {

    View view;
    AppCompatButton signIn, signUp;
    TextView agreement;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.initial_screen, container, false);

        signIn = view.findViewById(R.id.initial_screen_button1);
        signUp = view.findViewById(R.id.initial_screen_button2);
        agreement = view.findViewById(R.id.initial_screen_text2);

        // Sign In
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, new SignInScreen()).addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        // Sign Up
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, new SignUpScreen()).addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        // Terms Of Service
        agreement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, new TermsOfServiceScreen()).addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return view;
    }
}