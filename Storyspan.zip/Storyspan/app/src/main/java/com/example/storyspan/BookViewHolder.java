package com.example.storyspan;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BookViewHolder extends RecyclerView.ViewHolder {
    ImageView bookCover, bookRating;
    TextView bookName, bookAuthor;

    public BookViewHolder(@NonNull View itemView) {
        super(itemView);
        bookCover = itemView.findViewById(R.id.book_card_cover);
        bookRating = itemView.findViewById(R.id.book_card_rating);
        bookName = itemView.findViewById(R.id.book_card_bookname);
        bookAuthor = itemView.findViewById(R.id.book_card_authorname);
    }
}
