package com.example.storyspan;

import java.util.List;

public class Collection {
    String collectionName;
    int backgroundImage;
    List<Book> bookList;

    public Collection(String collectionName, int backgroundImage, List<Book> bookList) {
        this.collectionName = collectionName;
        this.backgroundImage = backgroundImage;
        this.bookList = bookList;
    }

    public String getCollectionName() {
        return collectionName;
    }

    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    public int getBackgroundImage() {
        return backgroundImage;
    }

    public void setBackgroundImage(int backgroundImage) {
        this.backgroundImage = backgroundImage;
    }

    public List<Book> getBookList() {
        return bookList;
    }

    public void setBookList(List<Book> bookList) {
        this.bookList = bookList;
    }
}
