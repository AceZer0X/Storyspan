package com.example.storyspan;

import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class SignUpScreen extends Fragment {

    View view;

    AppCompatButton signUp, viewPassword, viewRepeatedPassword, backArrow;
    EditText name, login, password, repeatedPassword;
    TextView signIn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sign_up_screen, container, false);

        signUp = view.findViewById(R.id.sign_up_screen_button);
        viewPassword = view.findViewById(R.id.sign_up_screen_lock1);
        viewRepeatedPassword = view.findViewById(R.id.sign_up_screen_lock2);
        backArrow = view.findViewById(R.id.sign_up_screen_back_arrow);
        name = view.findViewById(R.id.sign_up_screen_name);
        login = view.findViewById(R.id.sign_up_screen_login);
        password = view.findViewById(R.id.sign_up_screen_password);
        repeatedPassword = view.findViewById(R.id.sign_up_screen_repeated_password);
        signIn = view.findViewById(R.id.sign_up_screen_text8);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, new WelcomeScreen()).addToBackStack(null);
                fragmentTransaction.commit();
                // TODO: Сделать логику проверки пароля на совпадение и загрузки данных в случае совпадения пароля
            }
        });

        viewPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int start1 = password.getSelectionStart();
                int end1 = password.getSelectionEnd();
                if(password.getTransformationMethod() != null) {
                    password.setTransformationMethod(null);
                }
                else {
                    password.setTransformationMethod(new PasswordTransformationMethod());
                }
                password.setSelection(start1, end1);

                int start2 = repeatedPassword.getSelectionStart();
                int end2 = repeatedPassword.getSelectionEnd();
                if(repeatedPassword.getTransformationMethod() != null) {
                    repeatedPassword.setTransformationMethod(null);
                }
                else {
                    repeatedPassword.setTransformationMethod(new PasswordTransformationMethod());
                }
                repeatedPassword.setSelection(start2, end2);
            }
        });

        viewRepeatedPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int start1 = password.getSelectionStart();
                int end1 = password.getSelectionEnd();
                if(password.getTransformationMethod() != null) {
                    password.setTransformationMethod(null);
                }
                else {
                    password.setTransformationMethod(new PasswordTransformationMethod());
                }
                password.setSelection(start1, end1);

                int start2 = repeatedPassword.getSelectionStart();
                int end2 = repeatedPassword.getSelectionEnd();
                if(repeatedPassword.getTransformationMethod() != null) {
                    repeatedPassword.setTransformationMethod(null);
                }
                else {
                    repeatedPassword.setTransformationMethod(new PasswordTransformationMethod());
                }
                repeatedPassword.setSelection(start2, end2);
            }
        });

        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, new SignInScreen()).addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return view;
    }
}
