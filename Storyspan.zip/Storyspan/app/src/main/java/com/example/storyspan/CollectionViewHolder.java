package com.example.storyspan;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CollectionViewHolder extends RecyclerView.ViewHolder {
    public ImageView backgroundImage, rectImage;
    public TextView collectionName, showAll;
    public RecyclerView bookRecyclerView;

    public CollectionViewHolder(@NonNull View itemView) {
        super(itemView);
        backgroundImage = itemView.findViewById(R.id.collection_card_bg);
        rectImage = itemView.findViewById(R.id.collection_card_bg_rect);
        collectionName = itemView.findViewById(R.id.collection_card_name);
        showAll = itemView.findViewById(R.id.collection_card_showall);
        bookRecyclerView = itemView.findViewById(R.id.books);
    }
}
