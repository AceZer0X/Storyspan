package com.example.storyspan;

import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class SignInScreen extends Fragment {
    View view;

    AppCompatButton signIn, viewPassword, backArrow;
    EditText login, password;
    TextView signUp;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sign_in_screen, container, false);

        signIn = view.findViewById(R.id.sign_in_screen_button);
        viewPassword = view.findViewById(R.id.sign_in_screen_lock);
        backArrow = view.findViewById(R.id.sign_in_screen_back_arrow);
        login = view.findViewById(R.id.sign_in_screen_login);
        password = view.findViewById(R.id.sign_in_screen_password);
        signUp = view.findViewById(R.id.sign_in_screen_text4);

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, new MainScreen()).addToBackStack(null);
                fragmentTransaction.commit();
                // TODO: Сделать логику проверки данных
            }
        });

        viewPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int start = password.getSelectionStart();
                int end = password.getSelectionEnd();
                if(password.getTransformationMethod() != null) {
                    password.setTransformationMethod(null);
                }
                else {
                    password.setTransformationMethod(new PasswordTransformationMethod());
                }
                password.setSelection(start, end);
            }
        });

        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, new SignUpScreen()).addToBackStack(null);
                fragmentTransaction.commit();
            }
        });


        return view;
    }


}
