package com.example.storyspan;

public class Book {
    String bookName;
    String authorName;
    int coverImage;
    double rating;

    public Book(String bookName, String authorName, int coverImage, double rating) {
        this.bookName = bookName;
        this.authorName = authorName;
        this.coverImage = coverImage;
        this.rating = rating;
    }

    public String getBookName() {
        return bookName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public int getCoverImage() {
        return coverImage;
    }

    public double getRating() {
        return rating;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setCoverImage(int coverImage) {
        this.coverImage = coverImage;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
