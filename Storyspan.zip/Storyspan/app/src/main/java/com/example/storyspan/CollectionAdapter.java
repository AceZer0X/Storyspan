package com.example.storyspan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.storyspan.Collection;
import com.example.storyspan.CollectionViewHolder;
import com.example.storyspan.R;

import java.util.List;

public class CollectionAdapter extends RecyclerView.Adapter<CollectionViewHolder> {

    Context context;
    List<Collection> collectionList;

    public CollectionAdapter(Context context, List<Collection> cards) {
        this.context = context;
        this.collectionList = cards;
    }

    @NonNull
    @Override
    public CollectionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CollectionViewHolder(LayoutInflater.from(context).inflate(R.layout.collection_card, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CollectionViewHolder holder, int position) {
        holder.backgroundImage.setImageResource(collectionList.get(position).getBackgroundImage());
        holder.rectImage.setImageResource(R.drawable.collection_card_gray_rect);
        holder.collectionName.setText(collectionList.get(position).getCollectionName());
        holder.showAll.setText("Смотреть все");
        holder.bookRecyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        holder.bookRecyclerView.setAdapter(new BookAdapter(context, collectionList.get(position).getBookList()));
    }

    @Override
    public int getItemCount() {
        return collectionList.size();
    }
}
